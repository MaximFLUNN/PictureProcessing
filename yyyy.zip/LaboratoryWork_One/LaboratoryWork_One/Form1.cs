﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LaboratoryWork_One
{
    public partial class Form1 : Form
    {
        Bitmap image;
        public Form1()
        {
            InitializeComponent();
        }
        private void runFilter(Filters filter)
        {
            backgroundWorker1.RunWorkerAsync(filter);
        }

        private void открытьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Image files | *.png; *.jpg; *.bmp | All files (*.*) | *.*";
            
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                image = new Bitmap(dialog.FileName);
                pictureBox1.Image = image;
                pictureBox1.Refresh();
            }
        }

        private void инверсияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            runFilter(new InvertFilter());
            //InvertFilter filter = new InvertFilter();
            //backgroundWorker1.RunWorkerAsync(filter);
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            //groupBox1.Visible = true;
            Bitmap newImage = ((Filters)e.Argument).processImage(image, backgroundWorker1);
            if (backgroundWorker1.CancellationPending != true)
            {
                image = newImage;
            }
        }

        private void backgroundWorker1_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            progressBar1.Value = e.ProgressPercentage;
            groupBox1.Visible = true;
        }

        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (!e.Cancelled)
            {
                pictureBox1.Image = image;
                pictureBox1.Refresh();
            }
            progressBar1.Value = 0;
            groupBox1.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            backgroundWorker1.CancelAsync();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
        }

        private void размытиеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            runFilter(new BlurFilter());
            //Filters filter = new BlurFilter();
            //backgroundWorker1.RunWorkerAsync(filter);
        }

        private void Form1_ResizeEnd(object sender, EventArgs e)
        {
            pictureBox1.Image = image;
            pictureBox1.Refresh();
            Refresh();
        }

        private void размПоГаусуToolStripMenuItem_Click(object sender, EventArgs e)
        {
            runFilter(new GaussianFilter());
            //Filters filter = new GaussianFilter();
            //backgroundWorker1.RunWorkerAsync(filter);
        }

        private void чёрнобелоеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            runFilter(new GrayScaleFilter());
            //Filters filter = new GrayScaleFilter();
            //backgroundWorker1.RunWorkerAsync(filter);
        }

        private void сепияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            runFilter(new SepiaFilter());
            //Filters filter = new Sepia();
            //backgroundWorker1.RunWorkerAsync(filter);
        }

        private void увеличениеЯркостиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //runFilter(new SobelFilter_Y());
            runFilter(new Plusbrightness());
        }

        private void собельToolStripMenuItem_Click(object sender, EventArgs e)
        {
            runFilter(new SobelFilter());
        }

        private void резкостьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            runFilter(new Sharpness());
        }

        private void тиснениеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            runFilter(new Embossing());
        }

        private void тиснениеЦветноеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            runFilter(new Embossing(true));
        }

        private void выделениеГраницToolStripMenuItem_Click(object sender, EventArgs e)
        {
            runFilter(new BorderHighlightingSharr());
        }

        private void выделГраницПрюиттаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            runFilter(new BorderHighlightingPriutt());
        }

        private void медианаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            runFilter(new Median());
        }

        private void максимальныйToolStripMenuItem_Click(object sender, EventArgs e)
        {
            runFilter(new Maximum());
        }

        private void переносToolStripMenuItem_Click(object sender, EventArgs e)
        {
            runFilter(new Move());
        }

        private void поворотToolStripMenuItem_Click(object sender, EventArgs e)
        {
            runFilter(new Rotate());
        }

        private void волны1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            runFilter(new WaveOne());
        }

        private void волны2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            runFilter(new WaveTwo());
        }

        private void стеклоToolStripMenuItem_Click(object sender, EventArgs e)
        {
            runFilter(new Glass());
        }
    }
}
